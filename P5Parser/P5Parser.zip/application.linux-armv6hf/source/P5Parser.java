import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Collections; 
import java.math.BigDecimal; 
import java.math.BigInteger; 
import java.math.RoundingMode; 
import java.math.MathContext; 
import java.nio.file.Paths; 
import java.nio.file.Files; 
import java.nio.charset.Charset; 
import java.nio.charset.StandardCharsets; 
import java.math.BigInteger; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class P5Parser extends PApplet {

 //<>// //<>//
String ALLCHARS = "\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077\u2078\t\n\u2079\u00b1\u2211\u00ab\u00bb\u00e6\u00c6\u00f8\u203d\u00a7\u00b0\u00a6\u201a\u201b\u2044\u00a1\u00a4\u2116\u212e\u00bd !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u2190\u2191\u2193\u2260\u2264\u2265\u221e\u221a\u2550\u2551\u2500\u2502\u2261\u2219\u222b\u25cb\u05c0\u2032\u00ac\u207d\u207e\u215f\u2030\u00f7\u2564\u2565\u01a8\u01a7\u03b1\u0392\u03b2\u0393\u03b3\u0394\u03b4\u0395\u03b5\u0396\u03b6\u0397\u03b7\u0398\u03b8\u0399\u03b9\u039a\u03ba\u039b\u03bb\u039c\u03bc\u039d\u03bd\u039e\u03be\u039f\u03bf\u03a0\u03c0\u03a1\u03c1\u03a3\u03c3\u03a4\u03c4\u03a5\u03c5\u03a6\u03c6\u03a7\u03c7\u03a8\u03c8\u03a9\u03c9\u0101\u010d\u0113\u0123\u012b\u0137\u013c\u0146\u014d\u0157\u0161\u016b\u017e\u00bc\u00be\u2153\u2154\u215b\u215c\u215d\u215e\u2194\u2195\u2206\u2248\u250c\u2510\u2514\u2518\u256c\u253c\u2554\u2557\u255a\u255d\u2591\u2592\u2593\u2588\u25b2\u25ba\u25bc\u25c4\u25a0\u25a1\u2026\u203c\u2320\u2321\u034f\u2192\u201c\u201d\u2018\u2019";
//numbers         \u2502x xxxx    |  x xx  x    x       x x|xx     xxxxx xxxxxxxxxxx xxxx       xxxxxxxxxx    x /x xxx|xx  xxxxx    xx   xxxx xx xx xx x    xxx    x   x  /     x x       xxx           xx              xxx          x            xx                                   x x x\u2502
//strings         \u2502x  xxx    |  x xx  x            x x|xx     xxx x xxxxxxxxxxx  x x       x  xxxxxxx    x /x xx |x   xxxxx    xx   xxxx xx  x x  x    x               x     x       xx      xxx                x               xx       x                                        x x x\u2502
//arrays          \u2502x  x      |        x            x /|xx     / x x xxxxxxxxxxx                 xxxxx       x xx |x x xxxxx        xxxx  x   x x  x              /                                                              x/       /  D                 /                        \u2502
//^^ are the currently supported functions
String printableAscii =  " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
String ASCII = "";
//0,28,30,31,30,28,33, 29,26'25, 24
final int NONE = 0;
final int STRING = 2;
final int BIGDECIMAL = 3;
final int ARRAY = 4;
final int INS = 5;//input string
final int INN = 6;//input number
boolean saveDebugToFile;
boolean saveOutputToFile;
boolean logDecompressInfo;
boolean oldInputSystem;
boolean getDebugInfo;








StringList log = new StringList();
StringList expl = new StringList();
//import java.math.BigInteger;
//P5ParserV0_6 SK = this;
public void setup () {
  try {
    //System.out.println("hallo");
    //args = new String[]{"p.sogl", "3"};
    JSONObject options = loadJSONObject("options.json");
    saveDebugToFile = options.getBoolean("saveDebugToFile");
    saveOutputToFile = options.getBoolean("saveOutputToFile");
    logDecompressInfo = options.getBoolean("logDecompressInfo");
    oldInputSystem = options.getBoolean("oldInputSystem");
    getDebugInfo = options.getBoolean("getDebugInfo");
    //println(args.getClass());
    for (int i=0; i<256; i++)ASCII+=PApplet.parseChar(i)+"";
    String lines[];
    if (oldInputSystem) {
      lines = loadStrings("p.sogl");
      lines[0] = lines[0].replace("\u00b6","\n");
    } else {
      lines = args;
      lines[0] = readFile(dataPath(args[0]), StandardCharsets.UTF_8);
    }
    String program = lines[0];
    String[] inputs = new String[lines.length-1];
    for (int i = 1; i < lines.length; i++) {
      inputs[i-1]=lines[i];
    }
    //z\u2019\u00a4{\u00ab\u2565q;}x[p     { =4b*I*:O =Ob\"   =\u201d*o        ]I\u00b3r3w;3\\+
    new Executable(program, inputs).execute();
    if (saveOutputToFile) {
      String j =log.join("");
      if (j.charAt(0)=='\n') j=j.substring(1);
      //if (j.charAt(j.length()-1)=='\n') j=j.substring(0,j.length()-2);
      String[]o={j};
      saveStrings("output.txt", o);
    }
    if (saveDebugToFile) {
      String[]o2={expl.join("")};
      saveStrings("log.txt", o2);
    }
  } catch (Exception e) {
    
  }
  System.exit(0);
}
//small fix so this would work properly on APDE
/*int afix;
void draw() {
  afix++;
  if (afix>10) exit();
}*/



public BigDecimal B (float a) {
  try {
    return new BigDecimal(a);
  }
  catch (Exception e) { 
    println("B-floatE: \""+a+"\" - "+e.toString());
    return B(0);
  }
}
public BigDecimal B (String a) {
  try {
    return new BigDecimal(a);
  }
  catch (Exception e) { 
    println("B-string error from \""+a+"\": "+e.toString());
    return B(0);
  }
}
public boolean truthy (poppable p) {
  if (p.type==BIGDECIMAL) 
    return !p.bd.equals(B(0));
  else if (p.type==STRING)
    return p.s!="";
  else if (p.type==NONE)
    return false;
  return p.a.size()!=0;
}
public boolean falsy (poppable p) {
  if (p.type==BIGDECIMAL) 
    return p.bd.equals(B(0));
  else if (p.type==STRING)
    return p.s.equals("");
  else if (p.type==NONE)
    return true;
  return p.a.size()==0;
}



public void oprint (String o) {
  if (getDebugInfo) {
    System.out.print(o);
    log.append(o);
  }
}
public void oprintln (String o) {
  System.out.println(o);
  if (saveOutputToFile)
    log.append(o+"\n");
}
public void oprint (BigDecimal o) {
  System.out.print(o);
  if (saveOutputToFile)
    log.append(o.toString());
}
public void oprintln (BigDecimal o) {
  System.out.println(o);
  if (saveOutputToFile)
    log.append(o.toString()+"\n");
}
public void oprint (JSONArray o) {
  System.out.print(o);
  if (saveOutputToFile)
    log.append(o.toString());
}
public void oprintln (JSONArray o) {
  System.out.println(o);
  if (saveOutputToFile)
    log.append(o.toString()+"\n");
}
public void oprintln () {
  System.out.println();
  if (saveOutputToFile)
    log.append("\n");
}
/*void oprintln (Exception o) {
  println(o);
  expl.append(o.toString()+"\n");
}*/

public void eprintln (String o) {
  if (getDebugInfo) {
    System.err.println(o);
    if (saveDebugToFile)
      expl.append(o+"\n");
  }
}
public void eprint (String o) {
  if (getDebugInfo) {
    System.err.print(o);
    if (saveDebugToFile)
      expl.append(o);
  }
}
public String up0 (int num, int a) {
  String res = str(num);
  while (res.length()<a) {
    res = "0"+res;
  }
  return res;
}
public poppable array (String[] arr) {
  ArrayList<poppable> o = new ArrayList<poppable>();
  for (String s : arr)
    o.add(tp(s));
  return new poppable(o);
}
public ArrayList<poppable> array (poppable[] arr) {
  ArrayList<poppable> o = new ArrayList<poppable>();
  for (poppable s : arr)
    o.add(s);
  return o;
}
public poppable[] array (ArrayList<poppable> arr) {
  poppable[] o = new poppable[arr.size()];
  for (int i = 0; i < o.length; i++)
    o[i] = (arr.get(i));
  return o;
}
/*string[] stringArr(JSONArray j) {
  String[] s = new String[j.size()];
  for (int i = 0; i < s.length; i++) {
    s[i] = j.getString(i);
  }
  return s;
}*/
public ArrayList<poppable> ea() {
  return new ArrayList<poppable>();
}
public poppable tp(String s) {//to poppable
  return new poppable(s);
}
public poppable tp(BigDecimal bd) {
  return new poppable(bd);
}
public poppable tp(ArrayList<poppable> bd) {
  return new poppable(bd);
}
public String spaceup (String s, int l) {
  while (s.length()<l)
    s+=" ";
  return s;
}
public ArrayList<poppable> spacesquared(ArrayList<poppable> arr) {
  ArrayList<poppable> res = new ArrayList<poppable>();
  int l = 0;
  for (poppable b : arr) {
    if (b.s.length() > l)
      l = b.s.length();
  }
  int i = 0;
  for (poppable b : arr) {
    res.add(tp(spaceup(b.s, l)));
    i++;
  }
  return res;
}



public String readFile(String path, Charset encoding) {
  try {
    byte[] encoded = Files.readAllBytes(Paths.get(path));
    return new String(encoded, encoding);
  } catch (IOException e) {
    e.printStackTrace();
    return null;
  }
}
public ArrayList<int[]> compress (String s, int method) {
  /*
  method:
   0 - custom string
   1 - printable ASCII chars
   2 - english
   3 - box
   */
  toCompress = new ArrayList<int[]>();

  if (method == 0) {
    ArrayList<Character> used = new ArrayList<Character>();
    for (int i = 0; i < s.length(); i++) {
      if (!used.contains(s.charAt(i))) {
        used.add(s.charAt(i));
      }
    }
    if (s.length()<35+used.size()) {
      add(8, 0);
      add(32, s.length()-2-used.size());
    } else {
      add(8, 7);
      add(64, s.length()-2-used.size()-32);
    }
    Collections.sort(used);
    //byte[] chars = new byte[used.size()];
    println(used);
    add(97, compChars.indexOf(used.get(0)));
    int base = 97-compChars.indexOf(used.get(0))-1;
    for (int i = 1; i < used.size(); i++) {
      int diff = compChars.indexOf(used.get(i))-compChars.indexOf(used.get(i-1))-1;
      add(base, diff);
      base-=diff;
      if (i>1) base--;
    }
    add(base, base-1);
    for (int i = 0; i < s.length(); i++) 
      add(used.size(), used.indexOf(s.charAt(i)));
  }


  if (method == 1) {
    while (s.length()>0) {
      int length = min(s.length(), 18);
      println(length);
      if (length==1) {
        add(8,1);
        add(97,compChars.indexOf(s.charAt(0)));
        s="";
      } else if (length==2) {
        add(8,1);
        add(97,compChars.indexOf(s.charAt(0)));
        add(8,1);
        add(97,compChars.indexOf(s.charAt(1)));
        s="";
      } else {
        add(8, 3);
        add(16, length-3);
        for (int i = 0; i < length; i++) {
          add(97, compChars.indexOf(s.charAt(i)));
        }
        s = s.substring(length);
      }
    }
  }


  if (method == 2) {
    if (dict == null) dict = loadStrings("words2.0_wiktionary.org-Frequency_lists.txt");
    String[] words = s.split(" ");
    for (int j = 0; j < words.length/4+(words.length%4>0?1:0); j++) {
      add(8, 2);
      add(4, min(words.length-j*4, 4)-1);
      for (int i = 0; i < min(words.length-j*4, 4); i++) {
        String word = words[i+j*4];
        int id = 0;
        for (String c : dict) {
          if (c.equals(word)) break;
          id++;
        }
        if (id == dict.length-1) return null;
        if (id < 512) {
          add (2, 0);
          add (512, id);
          //o+=(pre(toString(toBase(2, BI(id))), 10, "0"));
        }
        else {
          add (2, 1);
          add (65536, id-512);
        }//o+=("1"+pre(toString(toBase(2, BI(id-512))), 16, "0"));
      }
    }
  }


  if (method == 3) {
    byte[] used = new byte[6];
    String useds = "";
    int uci = 0;
    String backslash = "\\";//PDE is strange... Try putting that in the use of the variable
    for (int i = 0; i < 6; i++) 
      if (s.contains(" /|_-\n".charAt(i)+"") | (i==1 && s.contains(backslash))) {
        used[i] = 1; 
        useds += " /|_-\n".charAt(i);
        uci++;
        if (i==1) {
          uci++;
          useds+="\\";
        }
      } else {
        used[i] = 0;
      }
    if (s.length()<34+uci) {
      add(8, 4);
      add(2, used);
      add(32, s.length()-2-uci);
    } else {
      add(8, 5);
      add(2, used);
      add(64, s.length()-34-uci);
    }
    for (int i = 0; i < s.length(); i++) 
      add(uci, useds.indexOf(s.charAt(i)));
  }

  /*o = "";
  BigInteger bi = BigInteger.ZERO;
  for (int i = toCompress.size()-1; i >= 0; i--) {
    bi = bi.multiply(BI(toCompress.get(i)[0])).add(BI(toCompress.get(i)[1]));
  }*/
  return toCompress;
}
public BigInteger toNum (ArrayList<int[]> baseData) {
  BigInteger bi = BigInteger.ZERO;
  for (int i = baseData.size()-1; i >= 0; i--) {
    bi = bi.multiply(BI(baseData.get(i)[0])).add(BI(baseData.get(i)[1]));
  }
  return bi;
}
public String[] toCmd (ArrayList<int[]> data) {
  /*try {
    while (bits.charAt(bits.length()-1)=='0') bits = bits.substring(0, bits.length()-1);
  } catch(Exception e) {}//it's ok, this means it's just empty :p*/
  String o = "";
  BigInteger bits = toNum(data);
  while (!bits.equals(BI(0))) {
    BigInteger[] temp = bits.divideAndRemainder(BI(250));
    bits = temp[0];
    byte c = temp[1].byteValue();
    o+=ALLCHARS.charAt(c&0xFF);
    //println(c&0xFF, ALLCHARS.charAt(c&0xFF));
  }
  String[] O = {o};
  saveStrings ("compressed", O);
  return O;
}
public ArrayList<int[]> compress(String s) {//(not so) smart compressor
  ArrayList<int[]> bc = new ArrayList<int[]>();//best = 0123, bc = because = code
  //boolean box = true;
  //for (char c : "\t!\"#$%&'()*+,-.0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^`abcdefghijklmnopqrstuvwxyz{}~".toCharArray()) 
    //if (s.contains(c+"")) box=false;
  try {
    ArrayList<int[]> c = compress(s, 1);
    if (s.equals(decompb(toNum(c)))) {
      bc = c;
    }
  }catch(Exception e){}
  //if (box)
  try {
    ArrayList<int[]> c = compress(s, 3);
    if (s.equals(decompb(toNum(c))) && (toNum(c).compareTo(toNum(bc))==-1||bc.equals(""))) {
      bc = c;
    }
  }catch(Exception e){}
  try {
    ArrayList<int[]> c = compress(s, 0);
    if (s.equals(decompb(toNum(c))) && (toNum(c).compareTo(toNum(bc))==-1||bc.equals(""))) {
      bc = c;
    }
  }catch(Exception e){}
  try {
    ArrayList<int[]> c = compress(s, 2);
    if (s.equals(decompb(toNum(c))) && (toNum(c).compareTo(toNum(bc))==-1||bc.equals(""))) {
      bc = c;
    }
  }catch(Exception e){}
  return bc;
}
ArrayList<int[]> toCompress;
public void add (int base, byte[] what) {
  for (int i = 0; i < what.length; i++) {
    int[] temp = new int[2];
    temp[0] = base;
    temp[1] = what[i];
    toCompress.add(temp);
  }
}
public void add (int base, int what) {
  //println(base, what);
  int[] temp = new int[2];
  temp[0] = base;
  temp[1] = what;
  toCompress.add(temp);
}

String compChars = "\n\t !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~                                                                                                                                                             ";
//note: here anywhere where byte is used it's most probably supposed to be a bit (base is an exception)
String[] dict;
public BigInteger fromBase (int base, byte[] num) {
  BigInteger o = BigInteger.valueOf(0);
  for (byte b : num) {
    o = o.multiply(BI(base)).add(BI(b&0xFF));
  }
  return o;
}
public BigInteger fromBase (int base, String num) {
  BigInteger o = BigInteger.valueOf(0);
  for (int i = 0; i < num.length(); i++) {
    o = o.multiply(BI(base)).add(BI(num.charAt(i)+""));
  }
  return o;
}
BigInteger decompressable;
public byte[] read (int base, int count) {
  byte[] o = new byte[count];
  for (int i = 0; i < count; i++) {
    BigInteger[] temp = decompressable.divideAndRemainder(BI(base));
    o[i] = temp[1].byteValue();
    decompressable = temp[0];
  }
  return o;
}
public byte read (int base) {
  byte o;
  BigInteger[] temp = decompressable.divideAndRemainder(BI(base));
  o = temp[1].byteValue();
  decompressable = temp[0];
  return o;
}
public int readInt (int base) {
  int o;
  BigInteger[] temp = decompressable.divideAndRemainder(BI(base));
  o = temp[1].intValue();
  decompressable = temp[0];
  return o;
}
public String getb (int base, int count) {
  String o = "";
  for (int i = 0; i < count; i++) {
    BigInteger[] temp = decompressable.divideAndRemainder(BI(base));
    o+= temp[1].intValue();
    decompressable = temp[0];
  }
  return o;
}
public byte[] toBase (int base, BigInteger b) {
  ArrayList<Byte> o = new ArrayList<Byte>();
  while (!b.equals(BigInteger.ZERO)) {
    BigInteger[] t = b.divideAndRemainder(BI(base));
    o.add(t[1].byteValue());
    b = t[0];
  }
  byte[] O = new byte[o.size()];
  for (int i = 0; i<o.size(); i++) {
    O[i]=o.get(o.size()-i-1);
  }
  return O;
}
public byte[] toArray (String s) {
  byte[] o = new byte[s.length()];
  for (int i=0; i<s.length(); i++)o[i]=(byte)PApplet.parseInt(s.charAt(i)+"");
  return o;
}
public byte[] toArray (String s, int group) {
  byte[] o = new byte[s.length()/group];
  for (int i=0; i<s.length(); i+=group)o[i/group]=(byte)PApplet.parseInt(s.substring(i, i+group));
  return o;
}
public BigInteger BI (String a) {
  try {
    return new BigInteger(a);
  }
  catch (Exception e) { 
    //oprintln(e);
    return BI("0");
  }
}
public BigInteger BI (byte a) {
  try {
    return BigInteger.valueOf(a&0xFF);
  }
  catch (Exception e) { 
    //oprintln(e);
    return BI("0");
  }
}
public BigInteger BI (long a) {
  try {
    return BigInteger.valueOf(a);
  }
  catch (Exception e) { 
    //oprintln(e);
    return BI("0");
  }
}
public String BAtoString(byte[] b) {
  String o = "";
  for (byte c : b) o+=c;
  return o;
}
public String pre (String s, int amo, String p) {
  while (s.length()<amo) s=p+s;
  return s;
}
public String post (String s, int amo, String p) {
  while (s.length()<amo) s+=p;
  return s;
}
public String decompress(String s) {
  byte[] bits = new byte[s.length()];
  for (int i = 0; i < s.length(); i++) {
    bits[s.length()-i-1] = (byte)ALLCHARS.indexOf(s.charAt(i));
  }
  return decompb(fromBase(250, bits));
}
int pos;
public String decompb(BigInteger in) {
  //println(in);
  pos = 0;
  decompressable = in;
  String out = "";
  byte last = -1;
  int lastD = -1;
  while(!decompressable.equals(BigInteger.ZERO)) {
    byte eq = read(8);
    if (eq==0 || eq==7) {
      int length = read(eq==0?32:64)+(eq==0?2:34);
                      //eq/7*32+32
      lastD = length;
      if(logDecompressInfo) print ("custom dictionary "+(eq==7?"long ":"")+"string with characters ");
      
      ArrayList<String> CU = new ArrayList<String>(); //chars used
      int base = 0;
      int closable = 0;
      int l = 0;//*/
      while (base<97 && l < 20) {
        l++;
        byte t = read(97-base+closable);
        base+=t+1;
        //println("test");
        if (base>96) break;
        String cc = compChars.charAt(base-1)+"";
        CU.add(cc);
        print("\""+cc+"\", ");
        if (CU.size()>=2) closable = 1;
      }
      length+=CU.size();
      print("and length "+length+": \"");
      //String bin = getb(ceil(log(charAm)*length/log(2)));
      byte[] based = read(CU.size(),length);//toBase(CU.length,fromBase(2,bin));
      String tout = "";//this out
      for (byte b : based) {
        tout += CU.get(b);
      }
      //while (tout.length()<length) tout = CU.get(0)+tout;
      if(logDecompressInfo) println(tout+"\"");
      out+=tout;
    }
    if (eq==2) {
      if (dict == null) dict = loadStrings("words2.0_wiktionary.org-Frequency_lists.txt");
      if (last==2 && lastD==4) out+=" ";
      int length = read(4)+1;
      lastD = length;
      if(logDecompressInfo) print (length + " english words: \"");
      String tout = "";
      for (int i = 0; i < length; i++) {
        if (read(2)==0) 
          tout+=dict[readInt(512)];
        else {
          tout+=dict[readInt(65536)+512];
        }
        if (i<length-1) tout+=" ";
      }
      if(logDecompressInfo) println(tout+"\".");
      out+=tout;
    }
    if (eq==5 | eq==4) {
      if(logDecompressInfo) print("boxstring with ");
      byte[] mode = read(2,6);
      StringList CU = new StringList(); //chars used
      int i = 0;
      for (byte cmode : mode) {
        if (cmode==1) CU.append(" /|_-\n".charAt(i)+"");
        if (i==1 & cmode==1) CU.append("\\");
        i++;
      }
      int length = read(eq==5?64:32)+(eq==5?34:2)+CU.size();
      if(logDecompressInfo) for (String s : CU) print ("\""+(s.equals("\n")?"\\n":s)+"\""+(s==CU.get(CU.size()-1)?", and "+length+" chars \"":", "));
      lastD = length;
      //println(bin);
      byte[] based = read(CU.size(),length);//toBase(CU.size(),fromBase(2,getb(ceil(log(CU.size())*length/log(2)))));
      String tout = "";//this out
      for (byte b : based) {
        tout += CU.get(b);
      }
      tout = pre(tout, length, CU.get(0));
      if(logDecompressInfo) println(tout+"\"");
      out+=tout;
    }
    if (eq==1) {
      String tout = compChars.charAt(read(97))+"";
      if(logDecompressInfo) println ("character \""+tout+"\"");
      lastD = 1;
      out+= tout;
    }
    if (eq==3) {
      int length = read(16)+3;
      lastD = length;
      byte[] base97 = read(97, length);
      String tout = "";
      for (byte b : base97) {
        tout+=compChars.charAt(b);
      }
      if(logDecompressInfo) println (length + " characters: \""+tout+"\"");
      out+= tout;
    }
    last = eq;
  }
  return out;
}
class Executable extends Preprocessable {
  Executable (String prog, String[] inputs) {
    super(prog, inputs);
  }
  public void execute() {
    poppable a = new poppable (p);
    poppable b = new poppable (B("0123456789"));
    ptr = -1;
    boolean ao = true;
    for (int TTTT = 0; TTTT < 1000000; TTTT++) {//while (true) {//
      ptr++;
      try {
        int sptr = ptr;
        if (ptr >= p.length()) break;
        char cc = p.charAt(ptr);
        char lastO = ' ';
        //--------------------------------------loop start--------------------------------------
        if (sdata[ptr]==3) {
          String res = "";
          try {
            while (sdata[ptr]==3) {
              res += p.charAt(ptr);
              ptr++;
            }
          }catch(Exception e){}
          if (p.charAt(ptr)=='\u2018')
          push(decompress(res));
          else
          push(res);
          //ptr++;
        } else if (qdata[ptr] != -1) {
          //quirk handling
          if (qdata[ptr]==12) {
            String[] qwerty = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
            push(qwerty);
            ptr+=3;
          }
          if (qdata[ptr]==0) {
            push("codegolf");
            ptr+=1;
          }
          if (qdata[ptr]==1) {
            push("stackexchange");
            ptr+=1;
          }
          if (qdata[ptr]==2) {
            push("qwertyuiop");
            push("asdfghjkl");
            push("zxcvbnm");
            ptr+=1;
          }
          if (qdata[ptr]==3) {
            push(p);
            ptr+=1;
          }
          if (qdata[ptr]==4) {
            new Executable(pop(STRING).s, new String[] {}).execute();
            ptr+=1;
          }
          if (qdata[ptr]==5) {
            String[] exs = { ".com", ".net", ".co.uk", ".gov" };
            push(exs);
            ptr++;
          }
          if (qdata[ptr]==6) {
            push("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
            ptr++;
          }
          if (qdata[ptr]==22) {
            push("1234567890");
            ptr+=1;
          }
        } else {
          
          if (cc=='\u00b9') {
            a = pop();
            b = a;
            ArrayList<poppable> ot = ea();
            while (true) {
              if (stack.size()==0) {
                if (a.type==b.type)
                  ot.add(a);
                else
                  push(a);
                break;
              } 
              if (a.type!=b.type) {
                push(a);
                break;
              }
              ot.add(a);
              //println(ot.get(ot.size()-1).a.get(0).s);
              a = pop();
            }
            ArrayList<poppable> o = ea();
            //tp(ot).println();
            for (int i = 0; i < ot.size(); i++) {
              o.add(ot.get(ot.size()-i-1));
            }
            push(o);
          }
          
          if (cc=='\u00b2') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL)
              push (a.bd.multiply(a.bd));
          }
  
          if (cc=='\u00b3') {
            a = pop(BIGDECIMAL);
            push(a);
            push(a);
            push(a);
          }
  
          if (cc=='\u2074') {
            a = pop(NONE);
            b = pop(NONE);
            push (b);
            push (a);
            push (b);
            //eprintln(":"+a.s+":::"+b.s+":");
            /*
          123
             cba
             1231
             cbac
             */
          }
  
          if (cc=='\u2075') {
            a = pop(NONE);
            b = pop(NONE);
            poppable c = pop(NONE);
            push (c);
            push (b);
            push (a);
            push (c);
            /*
          123
             cba
             1231
             cbac
             */
          }
          
          if (cc=='\u2076') {
            a = pop(BIGDECIMAL);
            b = pop(BIGDECIMAL);
            poppable c = pop(BIGDECIMAL);
            push(a);
            push(c);
            push(b);
          }
          
          if (cc=='\u00b1') {
            a = pop(STRING);
            if (a.type==STRING) {
              String res = "";
              for (int i = a.s.length()-1; i > -1; i--) {
                res += a.s.charAt(i);
              }
              push(res);
            } else if (a.type==BIGDECIMAL) {
              push (BigDecimal.ZERO.subtract(a.bd));
            } else if (a.type==ARRAY) {
              ArrayList<poppable> o = ea();
              for (int i = 0; i < a.a.size(); i++) {
                  o.add(a.a.get(a.a.size()-i-1));
              }
              push(o);
            }
          }
          
          if (cc=='\u2211') {
            a = pop();
            
            boolean useStrings = false;
            for (poppable c : a.a) {
              if (c.type!=BIGDECIMAL) {
                useStrings = true;
                break;
              }
            }
            if (useStrings) {
              String o = "";
              for (poppable c : a.a) {
                if (c.type!=ARRAY)
                  o+=c.s;
                else
                  o+=c.sline(false);
              }
            }
            
          }
          
          if (cc=='\u00ab') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) push (a.bd.multiply(B(2)));
            if (a.type==STRING) push (a.s.substring(1)+a.s.charAt(0));
          }
          
          if (cc=='\u00bb') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) push (a.bd.divideAndRemainder(B(2))[0]);
            if (a.type==STRING) push (a.s.charAt(a.s.length()-1)+a.s.substring(0, a.s.length()-1));
          }
          
          if (cc=='\u00f8') {
            push("");
          }
          
          if (cc=='\u00a6') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              push(a);
              push(a.bd.signum());
            }
          }
          
          if (cc=='\u2044') {
            a = pop(STRING);
            if (a.type==STRING|a.type==BIGDECIMAL) {
              push (a.s.length());
            }
          }
         
          if (cc==' ') {
            ptr++;
            push(p.charAt(ptr)+"");
          }
          if (cc=='\u2190') {
            break;
          }
          
          if (cc=='!') {
            push(falsy(pop(BIGDECIMAL)));
          }
          
          if (cc=='\"') {
            String res = "";
            ptr++;
            while (sdata[ptr]==3) {
              res += p.charAt(ptr);
              ptr++;
            }
            if (p.charAt(ptr)=='\u2018')
              push(decompress(res));
            else
              push(res);
          }
  
          if (cc=='#') push ("\"");
          
          if (cc=='%') {
            b = pop(BIGDECIMAL);
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL && b.type==BIGDECIMAL) {
              push (a.bd.remainder(b.bd));
            }
          }
          
          if (cc=='$') push ("\u201d");
          
          if (cc=='*') {
            if (stack.size()==0) {
              b=pop(BIGDECIMAL);
              a=pop(BIGDECIMAL);
              push(a);
              push(b);
              push(a.bd.multiply(a.bd));
            } else {
              a = pop();
              if (stack.size()==0) {
                b = pop(BIGDECIMAL);
                poppable t = a;
                a=b;
                b=t;
              } else
                b = pop();
              if (((a.type==BIGDECIMAL)&&(b.type==STRING))||((a.type==ARRAY)&&(b.type==BIGDECIMAL))) {
                poppable t = a;
                a = b;
                b = t;
              }
              if (a.type==BIGDECIMAL&&b.type==BIGDECIMAL) push(a.bd.multiply(b.bd)); 
              if ((a.type==STRING)&&(b.type==BIGDECIMAL)) {
                String res = "";
                for (long i = 0; i < b.bd.longValue(); i++) {
                  res+=a.s;
                }
                push(res);
              }
              if ((a.type==BIGDECIMAL)&&(b.type==ARRAY)) {
                ArrayList<poppable> arr = ea(); 
                for (int i = 0; i < b.a.size(); i++) {
                  String so = b.a.get(i).s;
                  arr.add(new poppable(""));
                  for (int j = 0; j < a.bd.intValue(); j++) {
                    arr.get(i).s+=so;
                  }
                }
                push(arr);
              }
            }
          }
  
          if (cc=='+') {
            if (stack.size()==0) {
              b=pop(BIGDECIMAL);
              a=pop(BIGDECIMAL);
              push(a);
              push(b);
              push(a.bd.add(b.bd));
            } else {
              a = pop();
              if (stack.size()==0) {
                if (a.type==BIGDECIMAL)
                  b = pop(BIGDECIMAL);
                else
                  b = pop(STRING);
                poppable t = a;
                a=b;
                b=t;
              } else
                b = pop();
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(a.bd.add(b.bd)); 
              else if ((a.type==BIGDECIMAL|a.type==STRING)&(b.type==BIGDECIMAL|b.type==STRING)) push(b.s+a.s);
              else if (a.type==STRING && b.type==ARRAY) {
                b.a.add(a);
                push(b);
              } else if (a.type==ARRAY && b.type==STRING) {
                ArrayList<poppable> o = ea();
                o.add(tp(b.s));
                for (int i = 0; i < a.a.size(); i++)
                  o.add(a.a.get(i));
                push(o);
              } else if (a.type==ARRAY && b.type==BIGDECIMAL) {
                ArrayList<poppable> o = ea();
                o.add(b);
                for (int i = 0; i < a.a.size(); i++)
                  o.add(a.a.get(i));
                push(o);
              } else if (a.type==BIGDECIMAL && b.type==ARRAY) {
                push(b.a.add(a));
              } else if (a.type==ARRAY && b.type==ARRAY) {
                b.copy().a.add(a.copy());
                push(b.a);
              }
            }
          }
          if (cc==',') push(sI());
          if (cc=='-') {
            if (stack.size()==0) {
              a=pop(BIGDECIMAL);
              if (a.type==BIGDECIMAL)
                push(B(0).subtract(a.bd));
            } else {
              a = pop(BIGDECIMAL);
              if (a.type==STRING)
                b = pop(STRING);
              else
                b = pop(BIGDECIMAL);
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(b.bd.subtract(a.bd));
  
              /*if (a.type==STRING&b.type==INT)push(a.s+b.i);//int+string, float+string
               if (a.type==INT&b.type==STRING)push(a.i+b.s);
               if (a.type==FLOAT&b.type==STRING)push(a.f+b.s);
               if (a.type==STRING&b.type==FLOAT)push(a.s+b.f);
               if (a.type==STRING&b.type==STRING)push(a.s+b.s);//string+string*/
            }
          }
          if (cc=='.') push(nI());
          if (cc=='/') {
            if (stack.size()==0) {
              a=pop(BIGDECIMAL);
              if (a.type==BIGDECIMAL)
                push(B(0).divide(a.bd));
            } else {
              a = pop(BIGDECIMAL);
              if (a.type==STRING)
                b = pop(STRING);
              else
                b = pop(BIGDECIMAL);
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(b.bd.divide(a.bd));
  
              /*if (a.type==STRING&b.type==INT)push(a.s+b.i);//int+string, float+string
               if (a.type==INT&b.type==STRING)push(a.i+b.s);
               if (a.type==FLOAT&b.type==STRING)push(a.f+b.s);
               if (a.type==STRING&b.type==FLOAT)push(a.s+b.f);
               if (a.type==STRING&b.type==STRING)push(a.s+b.s);//string+string*/
            }
          }
          if (cc>='0' & cc <='9') push(PApplet.parseInt(cc+""));
  
          if (cc==':') {
            a = pop(BIGDECIMAL);
            push(a);
            push(a);
          }
          if (cc=='<') {
            a=pop();//5
            b=pop();//3
            if (a.bd.subtract(b.bd).toString().charAt(0)=='-')
              push (false);
            else
              push (true);
          }
          if (cc=='=') {
            a=pop(STRING);
            b=pop(a.type);
            if (a.s.equals(b.s))
              push (true);
            else
              push (false);
          }
  
          if (cc=='>') {
            a=pop();//5
            b=pop();//3
            if (a.bd.subtract(b.bd).toString().charAt(0)=='-')
              push (true);
            else
              push (false);
          }
  
          if (cc=='?') {
            if (falsy(pop(BIGDECIMAL))) ptr=ldata[ptr];
          }
          
          if (cc=='@') push(" ");
  
          if (cc==';') {
            if (stack.size() == 0)
              push(nI());
            if (stack.size() == 1) 
              push(nI());
            a = pop();
            b = pop();
            push(a);
            push(b);
          }
  
          if (cc>='A' & cc <='E') {
            int cv = cc-'A';
            setvar(cv, pop(STRING));
          }
          if (cc=='F') {
            
          }
          if (cc=='G') {
            a = pop(BIGDECIMAL);
            b = pop(BIGDECIMAL);
            poppable c = pop(BIGDECIMAL);
            push (b);
            push (a);
            push (c);
            //123
            //cba
            //bac
            //231
          }
  
          if (cc=='H') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              push (a.bd.subtract(B(1)));
            }
          }
  
          if (cc=='I') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              push (a.bd.add(B(1)));
            }
          }
  
          if (cc=='J') {
            a = pop(BIGDECIMAL);
            if (a.type==STRING) {
              String c = a.s.charAt(a.s.length()-1)+"";
              push (a.s.substring(0, a.s.length()-1));
              push(c);
            }
            if (a.type==BIGDECIMAL) {
              push (B(sin(a.bd.floatValue())));
            }
          }
  
          if (cc=='K') {
            a = pop(BIGDECIMAL);
            if (a.type==STRING) {
              String c = a.s.charAt(0)+"";
              push (a.s.substring(1));
              push(c);
            }
            if (a.type==BIGDECIMAL) {
              push (B(cos(a.bd.floatValue())));
            }
          }
  
          if (cc=='L') push(B(10));
          if (cc=='M') push(B(100));
          if (cc=='N') push(B(256));
  
          if (cc=='O') {
            oprintln();
            pop(NONE).print();
            lastO=cc;
          }
          if (cc=='P') {
            if ("Oqpt".contains(lastO+""))oprintln();
            pop(NONE).print();
            ao = false;
            lastO=cc;
          }
          if (cc=='Q') {
            if ("Oqpt".contains(lastO+""))oprintln();
            a = pop(NONE);
            if ("Oqpt".contains(lastO+""))oprintln();
            pop(NONE).print(true);
            a.print(true);
            lastO= cc;
          }
          
          if (cc=='R') {
            a = pop();
            if (a.type==BIGDECIMAL) push (ASCII.charAt(a.bd.intValue()));
            ArrayList<poppable> res = ea();
            if (a.type==STRING) {
              for (int i = 0; i < a.s.length(); i++)
                res.add(tp(B(a.s.charAt(i)+0)));
              push(res);
            }
          }
          
          if (cc=='T') {
            if ("Oqpt".contains(lastO+""))oprintln();
            npop(NONE).print(true);
            lastO=cc;
            ao = false;
          }
          
          if (cc=='U') {
            a = pop(STRING);
            if (a.type==STRING) push (a.s.toUpperCase());
            else if (a.type==BIGDECIMAL) push (ceil(a.bd.floatValue()));
          }
          
          if (cc=='X') pop(NONE);
          
          if (cc=='W') {
            if (stack.size()==0) {
              a = pop(STRING);
              push("ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(a.s)+1);
            } else {
              a = pop();
              if (a.type==STRING)
                b = pop(BIGDECIMAL);
              if (a.type==BIGDECIMAL)
                b = pop(STRING);
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(a.bd.add(b.bd)); 
              if ((a.type==BIGDECIMAL)&(b.type==STRING)) {
                poppable t = a;
                a = b;
                b = t;
              }
              if ((b.type==BIGDECIMAL)&(a.type==STRING)) {
                int c = (b.bd.intValue()-1)%a.s.length();
                if (c<0)
                  c=c+a.s.length();
                push(a.s.charAt(c)+"");
              }
              if (a.type==STRING&b.type==STRING) {
                push(b.s.indexOf(a.s)+1);
              }
              if (a.type==STRING && b.type==ARRAY) {
                poppable t = a;
                a = b;
                b = t;
              }
              if (a.type==ARRAY && b.type==STRING) {
                push(a);
                boolean notfound = true;
                for (int i = 0; i < a.a.size(); i++) {
                  if (a.a.get(i).s.equals(b.s)) {
                    notfound = false;
                    push (i+1);
                    break;
                  }
                }
                if (notfound)
                  push(0);
              }
            }
            
          }
          
          if (cc=='Z')
            push("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  
          if (cc=="\\?".charAt(0)) {//Processing being weird again
            if (stack.size()==0) {
              a=pop(BIGDECIMAL);
              push(a.bd);
              push(a.bd.divideAndRemainder(B(10))[1].equals(B(0)));
            } else {
              a = pop();
              if (stack.size()==0) {
                b = pop(BIGDECIMAL);
              } else
                b = pop();
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(b.bd.divideAndRemainder(a.bd)[1].equals(B(0))); 
              //else if ((a.type==BIGDECIMAL|a.type==STRING)&(b.type==BIGDECIMAL|b.type==STRING)) push(b.s+a.s);
            }
          }
  
          if (cc=='[') {
            if (falsy(npop(NONE))) {
              ptr = ldata[ptr];
            }
          }
  
          if (cc=='^') {
            if (stack.size()==0) {
              a=pop(BIGDECIMAL);
              push(a.bd.multiply(B(0)));
            } else {
              a = pop();
              if (stack.size()==0) {
                if (a.type==STRING)
                  b = pop(STRING);
                else
                  b = pop(BIGDECIMAL);
                poppable t = a;
                a=b;
                b=t;
              } else
                b = pop();
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(b.bd.pow(a.bd.intValue())); 
              //else if ((a.type==BIGDECIMAL|a.type==STRING)&(b.type==BIGDECIMAL|b.type==STRING)) push(b.s+a.s);
            }
          }
          
          if (cc=='_') {
            a = pop();
            if (a.type==ARRAY) {
              for (int i = 0; i < a.a.size(); i++) {
                push(a.a.get(i));
              }
            }
          }
          
          if (cc>='a' & cc <='e') {
            int cv = cc-'a';
            push(new poppable (vars[cv], cv, this));
          }
          
          if (cc=='h') {
            a = pop(STRING);
            b = pop();
            poppable c = pop();
            push(b);
            push(c);
            push(a);
          }
          
          if (cc=='j') {
            a = pop(BIGDECIMAL);
            if (a.type==STRING) {
              if (a.s.length()==0) 
                push(""); 
              else
                push (a.s.substring(0, a.s.length()-1));
            }
            if (a.type==BIGDECIMAL) {
              push (B(sin(a.bd.floatValue()*PI/180)));
            }
          }
          
          if (cc=='i') {
            push(usedInputs.get(usedInputs.size()-1));
          }
          
          if (cc=='k') {
            a = pop(BIGDECIMAL);
            if (a.type==STRING) {
              push (a.s.substring(1));
            }
            if (a.type==BIGDECIMAL) {
              push (B(cos(a.bd.floatValue()*PI/180)));
            }
          }
          
          if (cc=='l') {
            a=npop(STRING);
            if (a.type==STRING|a.type==BIGDECIMAL) {
              //push (a);
              push (a.s.length());
            }
          }
          
          if (cc=='n') {
            a=pop();
            b=pop();
            String[] splat = new String[ceil(b.s.length()/a.bd.floatValue())];
            String part = b.s;
            for (int i = 0; i < floor(b.s.length()/a.bd.floatValue()); i++) {
              splat[i] = part.substring(0, a.bd.intValue());
              part = part.substring(a.bd.intValue());
              //println(part);
            }
            //println(part+"h");
            if (part.length()>0)
              splat[splat.length-1] = part + b.s.substring(0, a.bd.intValue()-part.length());
            push (array(splat));
          }
          
          if (cc=='o') {
            if ("Oqpt".contains(lastO+""))oprintln();
            pop(NONE).print(true);
            lastO=cc;
          }
          
          if (cc=='p') {
            oprintln();
            pop(NONE).print();
            ao = false;
            lastO=cc;
          }
          
          if (cc=='q') {
            oprintln();
            npop(NONE).print();
            lastO=cc;
          }
          
          if (cc=='r') {
            a=pop();
            if (a.type==STRING) push(B(a.s));
            if (a.type==BIGDECIMAL) push(a.bd.toString());
          }
  
          if (cc=='t') {
            oprintln();
            npop(NONE).print();
            ao = false;
            lastO=cc;
          }
          
          if (cc=='u') {
            a = pop(STRING);
            if (a.type==STRING) push (a.s.toLowerCase());
            else if (a.type==BIGDECIMAL) push (a.bd.round(new MathContext(1,RoundingMode.FLOOR)));
          }
          
          if (cc=='w') {
            if (stack.size()==0) {
              a=pop(STRING);
              push(ASCII.indexOf(a.s));
            } else {
              a = pop();
              if (stack.size()==0) {
                if (a.type==STRING)
                  b = pop(BIGDECIMAL);
                else
                  b = pop(STRING);
                poppable t = a;
                a=b;
                b=t;
              } else
                b = pop();
  
              if (a.type==BIGDECIMAL&b.type==BIGDECIMAL)push(a.bd.add(b.bd)); 
              if ((a.type==BIGDECIMAL)&(b.type==STRING)) push(b.s.indexOf(a.bd.toString())+1);
              if ((b.type==BIGDECIMAL)&(a.type==STRING)) push(a.s.indexOf(b.bd.toString())+1);
              
              if (a.type==BIGDECIMAL && b.type==ARRAY) {
                poppable t = a;
                a = b;
                b = t;
              }
              
              if (a.type==ARRAY && b.type==BIGDECIMAL) {
                push(a);
                int ptr = b.bd.intValue()-1;
                ptr=ptr%a.a.size();
                if (ptr<0)
                  ptr+=a.a.size();
                push(a.a.get(ptr));
              }
            }
          }
  
          if (cc=='x') {
            pop();
            pop();
          }
  
          if (cc=='z')
            push("abcdefghijklmnopqrstuvwxyz");
  
  
          if (cc=='{') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              data[ptr] = parseJSONObject("{\"N\":\""+a.s+"\",\"T\":3,\"L\":\"0\"}");//3-number, 2-string
              //eprintln(data[ptr].toString());
            } else
            if (a.type==STRING) {
              if (a.s.length()>0) {
                data[ptr] = parseJSONObject("{\"S\":\""+(a.s.substring(1))+"\",\"T\":2,\"L\":\"0\"}");//3-number, 2-string
                push(a.s.charAt(0)+"");
              }
            } else
            if (a.type==ARRAY) {
              if (a.a.size()>0) {
                push(a.a.get(0));
                a.a.remove(0);
                data[ptr] = parseJSONObject("{\"T\":4,\"L\":\"0\"}");//3-number, 2-string, 4-array
                dataA[ptr] = a;
                //println("%%%",data[ptr],"%%%");
              }
            }
          }
          if (cc=='\u222b') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              data[ptr] = parseJSONObject("{\"N\":\""+a.s+"\",\"T\":3,\"L\":\"0\"}");//3-number, 2-string
              if (B(data[ptr].getString("N")).intValue()>1) push(B(0));
            }
          }
          if (cc=='}') {
            //eprintln("==="+data[ldata[ptr]]+"`==="+data[ldata[ptr]].getString("N")+"==="+ldata[ptr]+"===");
            if (p.charAt(ldata[ptr])=='[') {
              if (truthy(npop(NONE))) {
                ptr = ldata[ptr];
              }
            } else if (p.charAt(ldata[ptr])==']') {
              if (truthy(pop(BIGDECIMAL))) {
                ptr = ldata[ptr];
              }
            } else if (p.charAt(ldata[ptr])=='{') {
              if (data[ldata[ptr]].getInt("T")==BIGDECIMAL) {
                if (!(B(data[ldata[ptr]].getString("N")).intValue()<=1)) {
                  ptr = ldata[ptr];
                  data[ptr] = parseJSONObject("{\"N\":\""+B(data[ptr].getString("N")).subtract(B(1)).toString()+"\",\"T\":3,\"L\":\""+B(data[ptr].getString("L")).add(B(1))+"\"}");
                  //eprintln(data[ptr].getString("N"));
                }
              } else
              if (data[ldata[ptr]].getInt("T")==STRING) {
                if (data[ldata[ptr]].getString("S").length()>0) {
                  ptr = ldata[ptr];
                  String s = data[ptr].getString("S");
                  data[ptr] = parseJSONObject("{\"S\":\""+(s.substring(1))+"\",\"T\":2,\"L\":\""+B(data[ptr].getString("L")).add(B(1))+"\"}");
                  push(s.charAt(0)+"");
                }
              } else if (data[ldata[ptr]].getInt("T")==ARRAY) {
                if (dataA[ldata[ptr]].a.size()>0) {
                  ptr = ldata[ptr];
                  poppable A = dataA[ptr];
                  push(A.a.get(0));
                  A.a.remove(0);
                  data[ptr] = parseJSONObject("{\"T\":4,\"L\":\""+B(data[ptr].getString("L")).add(B(1))+"\"}");
                  dataA[ptr] = A;
                }
              }
            } else if (p.charAt(ldata[ptr])=='\u222b') {
              if (data[ldata[ptr]].getInt("T")==BIGDECIMAL) {
                if (B(data[ldata[ptr]].getString("N")).intValue()>1) {
                  ptr = ldata[ptr];
                  data[ptr] = parseJSONObject("{\"N\":\""+B(data[ptr].getString("N")).subtract(B(1))+"\",\"T\":3,\"L\":\""+B(data[ptr].getString("L")).add(B(1))+"\"}");
                  push(PApplet.parseInt(data[ptr].getString("L")));
                  //oprintln(data[ptr].getString("N"));
                }
              }
            }
          }
          
          if (cc=='~') {
            a = pop(BIGDECIMAL);
            b = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL && b.type==BIGDECIMAL) {
              push(a.bd.subtract(b.bd));
            }
          }
          
          if (cc=='\u2260') {
            a = pop(STRING);
            b = pop(a.type);
            if (!a.s.equals(b.s))
              push (1);
            else
              push (0);
          }
          
          if (cc=='\u2264') {
            a = stack.get(0);
            stack.remove(0);
            push(a);
          }
          
          if (cc=='\u2265') {
            stack.add(0, pop());
          }
          
          if (cc=='\u2500') {
            b = pop(BIGDECIMAL);
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL && b.type==BIGDECIMAL) {
              if (b.bd.intValue()==2 && !b.inp)
                push(BAtoString(toBase(2, a.bd.toBigInteger())));
              else {
                ArrayList<poppable> out = ea();
                for (byte cb : toBase(b.bd.intValue(), a.bd.toBigInteger()))
                  out.add(new poppable(B(cb)));
                push(out);
              }
            }
          }
          
          if (cc=='\u2219') {
            a = pop();
            b = pop();
            if (((a.type==BIGDECIMAL)&&(b.type==STRING))||((a.type==STRING)&&(b.type==BIGDECIMAL))||((a.type==ARRAY)&&(b.type==BIGDECIMAL))) {
              poppable t = a;
              a = b;
              b = t;
            }
            if ((a.type==BIGDECIMAL)&&(b.type==ARRAY)) {
              ArrayList<poppable> out = new ArrayList<poppable>();
              for (int i = 0; i < b.a.size()*a.bd.longValue(); i++) {
                out.set(i,a.a.get(i%a.a.size()));
              }
              push(out);
            }
          }
          
          if (cc=='\u02b9') {
            a=pop();
            push (a.bd.toBigInteger().isProbablePrime(1000));
          }
          
          if (cc=='\u207d') {
            a = pop();
            push((a.s.charAt(0)+"").toUpperCase()+a.s.substring(1));
          }
          
          if (cc=='\u207e') {
            a = pop();
            push((a.s.charAt(0)+"").toLowerCase()+a.s.substring(1));
          }
          
          if (cc=='\u00f7') {
            a = pop(BIGDECIMAL);//5
            b = pop(BIGDECIMAL);//10 = 2
            if (a.type==BIGDECIMAL & b.type==BIGDECIMAL) push (b.bd.divideAndRemainder(a.bd)[0]);
          }
  
          
          if (cc=='\u2565') {
            a = npop(STRING);
            if (a.type==BIGDECIMAL)a=new poppable(a.toString());
            String s = a.s;
            for (int i = s.length()-2; i > -1; i--) {
              s+=s.charAt(i);
            }
            push(s);
          }
          
          if (cc=='\u2564') {
          }
          
          if (cc=='\u01a8') {
            ptr++;
            push(p.charAt(ptr)+""+p.charAt(ptr));
          }
          
          if (cc=='\u01a7') {
            ptr+=2;
            push(p.charAt(ptr-1)+""+p.charAt(ptr));
          }
          
          if (cc=='\u03b4') {
            a = pop();
            if (a.type==STRING) {
              String o = printableAscii.substring(0, printableAscii.indexOf(a.s));
              push(o);
            }
            if (a.type==BIGDECIMAL) {
              String o = "0123456789".substring(0, a.bd.intValue());
              push(o);
            }
          }
          
          if (cc=='\u0394') {
            a = pop();
            if (a.type==STRING) {
              //should be expanded
              String o = printableAscii.substring(0, printableAscii.indexOf(a.s)+1);
              push(o);
            }
            if (a.type==BIGDECIMAL) {
              //should be expanded
              String o = "123456789".substring(0, a.bd.intValue());
              push(o);
            }
          }
          
          if (cc=='\u0398') {
            b = pop(STRING);
            a = pop(STRING);
            String curr = "";
            ArrayList<poppable> out = ea();
            int count = a.s.length();
            for (int i = 0; i < count; i++) {
              if (a.s.substring(0,b.s.length()).equals(b.s)) {
                out.add(new poppable(curr));
                a.s = a.s.substring(b.s.length());
                i+=b.s.length()-1;
                curr = "";
              } else {
                curr+=a.s.charAt(0);
                a.s = a.s.substring(1);
              }
            }
            if (!curr.equals(""))
              out.add(new poppable(curr));
            push(out);
          }
          if (cc=='\u03b8') {
            a = pop();
            String curr = "";
            ArrayList<poppable> out = ea();
            int count = a.s.length();
            for (int i = 0; i < count; i++) {
              if (a.s.charAt(0)==' ') {
                out.add(new poppable(curr));
                curr = "";
              } else {
                curr+=a.s.charAt(0);
              }
              a.s = a.s.substring(1);
            }
            if (!curr.equals(""))
              out.add(new poppable(curr));
            push(out);
          }
          
          if (cc=='\u03bb') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              ArrayList<poppable> out = ea();
              for (BigDecimal i = B(1); i.compareTo(a.bd)!=0; i = i.add(B(1)))
                if (a.bd.divideAndRemainder(i)[1].equals(B(0)))
                  out.add(new poppable(i));
              push(out);
            }
          }
          
          if (cc=='\u039b') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              ArrayList<poppable> out = ea();
              for (BigDecimal i = B(1); i.compareTo(a.bd)!=1; i = i.add(B(1)))
                if (a.bd.divideAndRemainder(i)[1].equals(B(0)))
                  out.add(new poppable(i));
              push(out);
            }
          }
          
          if (cc=='\u039f') {
            poppable c = pop();
            b = pop(c.type);
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL&&b.type==BIGDECIMAL&&c.type==BIGDECIMAL) {
              if (a.bd.compareTo(b.bd)==-1)
                a.bd=b.bd;
              if (a.bd.compareTo(c.bd)==1)
                a.bd=c.bd;
              push(a);
            }
            if (a.type==BIGDECIMAL&&b.type==STRING&&c.type==STRING) {
              String o = "";
              for (int i = 0; i < a.bd.intValue()-1; i++) {
                o+=b.s+c.s;
              }
              push (o+b.s);
            }
            if (a.type==STRING&&b.type==BIGDECIMAL&&c.type==STRING) {
              String o = "";
              for (int i = 0; i < b.bd.intValue(); i++) {
                o+=a.s+c.s;
              }
              push (o+a.s);
            }
          }
          
          if (cc=='\u03c1') {
            a = pop();
            if (a.type==STRING) push(new StringBuilder(a.s).reverse().toString().equals(a.s));
          }
          
          if (cc=='\u03a4') {
            a = pop();
            if (a.type==BIGDECIMAL)
              push(log(a.bd.floatValue()));
          }
          
          if (cc=='\u03c4') {
            a = pop();
            if (a.type==BIGDECIMAL)
              push(log(a.bd.floatValue())/log(2));
          }
          
          if (cc=='\u03a5') {
            b = pop();
            a = pop();
            if (a.type==BIGDECIMAL && b.type==BIGDECIMAL)
              push(log(a.bd.floatValue())/log(b.bd.floatValue()));
          }
          
          if (cc=='\u03a8') {
            a = npop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              push (floor(random(a.bd.intValue()))+1);
            }
            if (a.type==STRING) {
              push(printableAscii.charAt(floor(random(a.s.charAt(0)))));
            }
          }
          
          if (cc=='\u03c8') {
            a = pop(BIGDECIMAL);
            if (a.type==BIGDECIMAL) {
              push (floor(random(a.bd.intValue()+1)));
            }
            if (a.type==STRING) {
              push(a.s.charAt(floor(random(a.s.length())))+"");
            }
          }
          
          if (cc=='\u0101') push(ea());
          
          if (cc=='\u010d') {
            a = pop(STRING);
            if (a.type == STRING) {
              String[] s = new String[a.s.length()];
              for (int i = 0; i < a.s.length(); i++)
                s[i] = a.s.charAt(i)+"";
              push(s);
            } else if (a.type == ARRAY) {
              boolean string = false;
                for (poppable c : a.a)
                  if (c.type==STRING||c.type==ARRAY)
                    string = true;
              if (string) {
                String out = "";
                for (poppable s : a.a)
                  out+=s.s;
                push(out);
              } else {
                BigDecimal out = BigDecimal.ZERO;
                for (poppable bd : a.a)
                  out=out.add(bd.bd);
                push(out);
              }
            }
          }
          
          if (cc=='\u0157') {
            a = pop();//last (to what to replace) 1st array
            b = pop();//middle (what to replace) 2nd arrat
            poppable c = pop();//first (from what to replace) 3rd array
            //poppable t;
            int ac = (a.type==ARRAY?1:0)+(b.type==ARRAY?1:0)+(c.type==ARRAY?1:0);
            /*if (b.type==ARRAY && a.type!=ARRAY) {
              t = a;
              a = b;
              b = t;
            }
            if (c.type==ARRAY && b.type!=ARRAY) {
              t = b;
              b = c;
              c = t;
            }
            if (b.type==ARRAY && a.type!=ARRAY) {
              t = a;
              a = b;
              b = t;
            }*/
            if (ac == 0) {
              push(c.s.replace(b.s,a.s));
            } else if (ac==1) {
              if (c.type==ARRAY) {
                ArrayList<poppable> o = new ArrayList<poppable>();
                for (int i = 0; i < a.a.size(); i++)
                  o.add(tp(a.a.get(i).s.replace(b.s,a.s)));
                push(o);
              } else if (b.type==ARRAY) {
                String o = c.s;
                for (poppable p : b.a)
                  o = o.replace(p.s, a.s);
                push (o);
              } else {
                String o = "";
                int item = 0;
                int length = c.s.length();
                for (int i = 0; i < length; i++) {
                  if (c.s.startsWith(b.s)) {
                    o+=a.a.get(item%a.a.size());
                    item++;
                  } else {
                    o+=c.s.charAt(0);
                  }
                  c.s = c.s.substring(1);
                }
                push(o);
              }
            }
          }
          
          if (cc=='\u017e') {
            poppable d = pop(ARRAY);
            poppable c = pop(BIGDECIMAL);
            b = pop(BIGDECIMAL);
            a = pop(ARRAY);
            
          }
          
          if (cc=='\u00bc') {
            a = pop();
            if (a.type==BIGDECIMAL)
              push (a.bd.multiply(B(1)).divide(B(4)));
          }
          
          if (cc=='\u00be') {
            a = pop();
            if (a.type==BIGDECIMAL)
              push (a.bd.multiply(B(3)).divide(B(4)));
          }
          
          if (cc=='\u253c') {
            b = pop();
            a = pop();
            if (a.type==ARRAY) {
              if (b.type==STRING) {
                int maxlen = 0;
                for (poppable c : a.a) 
                  if (c.s.length()>maxlen) 
                    maxlen = c.s.length();
                for (poppable c : a.a) 
                  while (c.s.length()<maxlen)
                    c.s+=" ";
                for (int i = 0; i < b.s.length(); i++) {
                  a.a.set(i%a.a.size(),tp(a.a.get(i%a.a.size()).s+b.s.charAt(i)));
                }
                push(a);
              }
              if (b.type==ARRAY) {
                while (a.a.size()<b.a.size())
                  a.a.add(new poppable(""));
                while (b.a.size()<a.a.size())
                  b.a.add(new poppable(""));
                ArrayList<poppable> s = spacesquared(a.a);
                ArrayList<poppable> e = spacesquared(b.a);
                ArrayList<poppable> res = new ArrayList<poppable>();
                for (int i = 0; i < s.size(); i++) {
                  res.add(tp(s.get(i).s+e.get(i).s));
                }
                push(res);
              }
            }
            if (a.type==STRING) {
              if (b.type==ARRAY) {
                int maxlen = 0;
                for (poppable c : b.a) 
                  if (c.s.length()>maxlen) 
                    maxlen = c.s.length();
                for (poppable c : b.a) 
                  while (c.s.length()<maxlen)
                    c.s+=" ";
                for (int i = 0; i < a.s.length(); i++) {
                  b.a.set(i%b.a.size(),tp(a.s.charAt(i)+b.a.get(i%b.a.size()).s));
                }
                for (int i = a.s.length();i%b.a.size()!=0;i++) {
                  b.a.set(i%b.a.size(),tp(" "+b.a.get(i%b.a.size()).s));
                }
                push(b);
              }
            }
          }
          
          if (cc=='\u2019') {
            ptr++;
            push(ALLCHARS.indexOf(p.charAt(ptr))+11);
          }
          
          if (cc=='\u201d') {
            push("");
          }
        }
        //while (millis()<CTR*20);
        if (getDebugInfo) {
          //eprintln("`"+cc+"`@"+((sptr+"").length()==1?"0"+sptr:sptr)+": "+stack.toString().replace("\n  ", "").replace("\n", ""));
          eprint("`"+cc+"`@"+up0(sptr, str(p.length()).length())+": [");
          long EPC=0;
          for (poppable EP : stack) {
            EPC++;
            eprint(EP.sline(true));
            if (EPC<stack.size()) eprint(", ");
          }
          eprintln("]");
        }
        //--------------------------------------loop end--------------------------------------
      } 
      catch (Exception e) {
          eprintln("executioneE: ");
          e.printStackTrace();
      }
    }
    if (ao) {
      oprintln();
      pop(STRING).print();
    }
  }
}
class poppable {
  BigDecimal bd = new BigDecimal("0");
  String s = "";
  ArrayList<poppable> a = new ArrayList<poppable>();
  int type = 0;
  boolean inp = false;
  poppable (String ii) {
    type = STRING;
    s = ii;
  }
  poppable (BigDecimal ii) {
    type = BIGDECIMAL;
    bd = ii;
    s = ii.toString();
  }
  poppable (int ii) {
    type = ii;
    //bd = B(ii);
  }
  poppable (ArrayList<poppable> ii) {
    type = ARRAY;
    a = ii;
  }
  poppable () {
  }
  poppable (poppable tc) {
    type = tc.type;
    s = tc.s;
    a = tc.a;
    bd = tc.bd;
    inp = tc.inp;
  }
  poppable (poppable o, int varsave, Executable ex) {
    type = o.type;
    if (o.type==INS) {
      type = STRING;
      s = ex.sI().s;
      inp = true;
      ex.setvar(varsave, this);
    }
    if (o.type==INN) {
      type = BIGDECIMAL;
      bd = ex.nI().bd;
      s = bd.toString();
      inp = true;
      ex.setvar(varsave, this);
    }
    if (o.type==BIGDECIMAL) {
      bd = o.bd;
      s = bd.toString();
    }
    if (o.type==STRING) {
      s = o.s;
    }
  }
  poppable (BigDecimal ii, boolean imp) {
    type = BIGDECIMAL;
    bd = ii;
    s = ii.toString();
    inp = imp;
  }
  poppable (String ii, boolean imp) {
    type = STRING;
    s = ii;
    inp = imp;
  }
  poppable (ArrayList<poppable> ii, boolean imp) {
    type = ARRAY;
    a = ii;
    inp = imp;
  }
  public void print () {
    if (type==STRING) oprint(s);
    if (type==BIGDECIMAL) oprint(bd);
    if (type==ARRAY) printArr();
  }
  public void print (boolean normArr) {
    if (type==STRING) oprint(s);
    if (type==BIGDECIMAL) oprint(bd);
    if (type==ARRAY)
      if (normArr)
        oprint(a.toArray().toString());
      else
        printArr();
  }
  public void println () {
    if (type==STRING) oprintln(s);
    if (type==BIGDECIMAL) oprintln(bd);
    if (type==ARRAY) printArr();
  }
  public void println (boolean normArr) {
    if (type==STRING) oprintln(s);
    if (type==BIGDECIMAL) oprintln(bd);
    if (type==ARRAY) {
      if (normArr) {
        eprintln ("[\n");
        for (int i = 0; i < a.size()-1; i++) {
          a.get(i).println(true);
          eprintln(",");
        }
        eprintln("]");
      } else {
        printArr();
        println();
      }
    }
  }
  public void printArr() {
    for (int i = 0; i < a.size()-1; i++) {
      a.get(i).println();
    }
    if (a.size()>0) a.get(a.size()-1).print();
  }
  public String sline(boolean escape) {
    String toEscape = s;
    if (escape) {
      toEscape = toEscape.replace("\\", "\\\\");
      toEscape = toEscape.replace("\n", "\\n");
      toEscape = toEscape.replace("\"", "\\\"");
    }
    if (type==STRING) return "\""+toEscape+"\"";
    if (type==BIGDECIMAL) return bd.toString();
    if (type==ARRAY) {
      String o = "[";
      for (int i = 0; i < a.size(); i++) 
        o+=a.get(i).sline(escape)+(i+1==a.size()?"]":", ");
      return o;
    }
    return "ERROR";
  }
  public poppable copy() {
    if (type==BIGDECIMAL) {
      return tp(bd);
    }
    if (type==BIGDECIMAL) {
      return tp(s);
    }
    ArrayList<poppable> out = ea();
    for (poppable cc : a) {
      out.add(cc.copy());
    }
    return tp(out);
  }
}
String quirkLetters = " 0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
String[] quirks = {"0*0/","1*1/","2*2/","3*3/","4*4/","5*5/","6*6/","7*7/","8*8/","9*9/","0/0*","1/1*","2/2*","3/3*","4/4*","5/5*","6/6*","7/7*","8/8*","9/9*","UU","uu","SU","Su","US","uS","!?","\u00b2\u00b2","!!","2\u00f7"};
class Preprocessable {
  ArrayList<poppable> stack = new ArrayList<poppable>();
  ArrayList<poppable> usedInputs = new ArrayList<poppable>();
  int ptr = 0;
  int inpCtr = -1;
  String[] inputs;
  int[] sdata;
  int[] ldata;
  int[] qdata;
  int[] lef; 
  JSONObject[] data;
  poppable[] dataA;
  poppable[] vars;
  String p;
  Preprocessable (String prog, String[] inputs) {
    preprocess(prog, inputs);
  }
  public Preprocessable preprocess(String prog, String[] inputs) {
    this.inputs = inputs;
    p = prog;
    sdata = new int[p.length()];
    ldata = new int[p.length()];
    qdata = new int[p.length()];
    data = new JSONObject[p.length()];
    dataA = new poppable[p.length()];
    for (int i = 0; i < sdata.length; i++) {
      sdata[i]=0;
      ldata[i]=0;
      qdata[i]=-1;
    }
    //variable defaults
    vars = new poppable[5];
    vars[0] = new poppable (B(0));
    vars[1] = new poppable (INN);
    vars[2] = new poppable (ea());
    vars[3] = new poppable (INS);
    vars[4] = new poppable (INN);
    char[] skippingChars = {' ', '\u0396', '\u01a8', '\u01a7'};
    int[] skippingCharsL = { 1,   2,   2,   2 };
    /*
    SDATA: (string data)
     1 - string ender
     2 - string starter
     3 - string
     4 - compressed ender
     LDATA: (loop/if data)
     "{", "?", "F", "[", "]" - ending pointer
     "}" - starting pointer (for loops)
     */
    //for (int i = 0; i < p.length(); i++) if (p.charAt(i)=='\u2192') CT = true;
      if (p.contains("\u2192")) {
        //println (p.contains("\u2192"));
        int i = 0;
        String res = "";
        while (p.charAt(i)!='\u2192') {
          //println(p.charAt(i)+" \u2192 "+(p.charAt(i)!='\u2192'));
          res+=p.charAt(i);
          i++;
        }
      eprintln("preprocessor: "+p.replace("\n", "\u00b6"));
      //5{t}\u2192Y \Y /Y
      //println(res+"\n"+i+"\n"+p);
      return preprocess(p.substring(i+2).replace(p.charAt(i+1)+"", res), inputs);
    }
    for (int i = 0; i < p.length(); i++) {
      boolean skip = false;
        for (int j = 0; j < skippingChars.length; j++)
          if (skippingChars[j]==p.charAt(i)) {
          skip = true;
          i+=skippingCharsL[j];
        }
      if (skip) {
        continue;
      }
      if (p.charAt(i)=='\u201d'||p.charAt(i)=='\u2018') {
        sdata[i]=1;
        int j=i-1;
        while (true) {
          if (j == -1) break;
          sdata[j]=3;
          j--;
          if (j == -1) break;
          if (p.charAt(j)=='"') {
            sdata[j]=2;
            break;
          }
          if (sdata[j]<3&sdata[j]>0) break;
        }
      } else if (p.charAt(i)=='"') {
        sdata[i]=2;
        i++;
        while (true) {
          if (i == p.length()) break;
          sdata[i]=3;
          if (p.charAt(i)=='\u201d'||p.charAt(i)=='\u2018') {
            sdata[i]=1;
            break;
          }
          i++;
          if (i == p.length()) break;
          if (sdata[i]<3&sdata[i]>0) break;
        }
      } else for (int j = 0; j < quirks.length; j++)
        if (p.substring(i).startsWith(quirks[j]))
          for (int k = 0; k < quirks[j].length(); k++)
            qdata[k+i] = j;
    }
    IntList loopStack = new IntList();
    for (int i = 0; i < p.length(); i++) {
      if (p.charAt(i)==' ') {
        i++;
        continue;
      }
      if (p.charAt(i)=='\u01a7') {
        i+=2;
        continue;
      }
      while (i<sdata.length && sdata[i]!=0) i++;
      if (i>sdata.length-1) break;
      if ("{?[]F\u222b".contains(p.charAt(i)+"")) {
        loopStack.append(i);
      }
      if (p.charAt(i)=='}'|p.charAt(i)=='\u2190') {
        if (loopStack.size()>0) {
          ldata[i]=loopStack.get(loopStack.size()-1);
          int temp = loopStack.get(loopStack.size()-1);
          loopStack.remove(loopStack.size()-1);
          ldata[temp] = i;
        } else {
          ldata[i]=0;
        }
      }
    }
    if (loopStack.size()>0) {
      for (int i = 0; i < loopStack.size(); i++) p+='}';
      eprintln("preprocessor: "+p.replace("\n", "\u00b6"));
      return preprocess(p, inputs);
    }
    if (!getDebugInfo) return this;
    eprintln("program: "+p.replace("\n", "\u00b6"));
    eprint("|");
    for (int i=0; i<sdata.length; i++)eprint((p.charAt(i)+(i==sdata.length-1?"|":" ")).replace("\n", "\u00b6"));
    eprint(" chars\n|");
    for (int i=0; i<sdata.length; i++)eprint(sdata[i]+"|");
    eprint(" strings\n|");
    for (int i=0; i<sdata.length; i++)eprint(quirkLetters.charAt(qdata[i]+1)+"|");
    eprint(" quirks\n|");
    for (int i=0; i<sdata.length; i++)eprint((ldata[i]+"").length()==1?ldata[i]+"|":ldata[i]+"");
    eprint(" loops\n|");
    for (int i=0; i<sdata.length; i++)eprint(i%10+"|");
    eprint(" 1s\n|");
    for (int i=0; i<sdata.length; i++)eprint(i/10%10+"|");
    eprint(" 10s\n\n");
    return this;
  }
  public poppable sI () {
    try {
      inpCtr++;
      if (inpCtr>=inputs.length)
        inpCtr = 0;
      usedInputs.add(new poppable(inputs[inpCtr], true));
      return new poppable (inputs[inpCtr], true);
    } 
    catch (Exception e) {
      oprintln("String input error at inpCtr "+inpCtr+": "+e);
      return new poppable ("", false);
    }
  }

  public poppable nI () {
    try {
      inpCtr++;
      if (inpCtr>=inputs.length)
        inpCtr = 0;
      usedInputs.add(new poppable(B(inputs[inpCtr]), true));
      return new poppable (B(inputs[inpCtr]), true);
    } 
    catch (Exception e) {
      oprintln("nI error: "+ e);
      return new poppable (B(0), true);
    }
  }
  public void setvar (int v, poppable p) {
    vars[v]=p;
    }
  public void push (String s) {
    stack.add(new poppable(s));
  }
  public void push (long l) {
    stack.add(new poppable(new BigDecimal(l)));
  }
  public void push (float l) {
    stack.add(new poppable(new BigDecimal(l)));
  }
  public void push (ArrayList<poppable> a) {
    stack.add(new poppable(a));
  }
  public void push (String[] a) {
    stack.add(new poppable(array(a)));
  }
  public void push (boolean b) {
    stack.add(new poppable(B(b?"1":"0")));
  }
  public void push (BigDecimal d) {
    stack.add(new poppable(d));
  }
  public void push (poppable p) {
    stack.add(new poppable(p));
  }
  
  public poppable pop (int implicitType) {
    if (stack.size()>0) {
      return pop();
    }
    if (implicitType == BIGDECIMAL) return nI();
    else if (implicitType == STRING) return sI();
    else return new poppable(B("0"));
  }
  
  public poppable pop () {
    try {
      poppable r = gl();
      stack.remove(stack.size()-1);
      return r;
    } catch (Exception e) {
      println("poppingE: "+e.toString());
      String ns = sI().s;
      boolean isString = false;
      for (char c : ns.toCharArray())
        if (c<'0' || c>'9') {
          isString = true;
          break;
        }
      if (isString) {
        return tp(ns);
      } else {
        return tp(B(ns));
      }
    }
  }
  
  public poppable npop (int implicitType) {
    if (stack.size()>0) {
      return gl();
    }
    if (implicitType == BIGDECIMAL)
      return nI();
    else if (implicitType == STRING)
      return sI();
    else return new poppable();
  }
  public poppable gl () {//get last
    if (stack.size()==0) {
      return new poppable (B(0));
    }
    poppable g = stack.get(stack.size()-1);
    return g;
  }
}
UU U = new UU();
class UU {
  public JSONArray toJSON (float[][] arrIn) {
    JSONArray out = new JSONArray();
    int i1 = 0;
    for (float[] e1 : arrIn) {
      JSONArray O2 = new JSONArray();
      for (float e2 : e1) {
        O2.append(e2);
      }
      out.setJSONArray(i1, O2);
      i1++;
    }
    return out;
  }
  public JSONArray toJSON (int[][] arrIn) {
    JSONArray out = new JSONArray();
    int i1 = 0;
    for (int[] e1 : arrIn) {
      JSONArray O2 = new JSONArray();
      for (int e2 : e1) {
        O2.append(e2);
      }
      out.setJSONArray(i1, O2);
      i1++;
    }
    return out;
  }
  public JSONArray toJSON (float[] arrIn) {
    JSONArray out = new JSONArray();
    for (float e2 : arrIn) {
      out.append(e2);
    }
    return out;
  }
  public JSONArray toJSON (int[] arrIn) {
    JSONArray out = new JSONArray();
    for (int e2 : arrIn) {
      out.append(e2);
    }
    return out;
  }
  public int[] toArray (JSONArray JSONIn) {
    //println(JSONIn.size());
    //println(JSONIn.getJSONArray(0).size());
    int[] out = new int[JSONIn.size()];
    for (int i1 = 0; i1 < JSONIn.size(); i1++) {
      out[i1] = JSONIn.getInt(i1);
    }
    return out;
  }
  public int[][] toArray2 (JSONArray JSONIn) {
    //println(JSONIn.size());
    //println(JSONIn.getJSONArray(0).size());
    int[][] out = new int[JSONIn.size()][0];
    for (int i1 = 0; i1 < JSONIn.size(); i1++) {
      int[] out2 = new int[JSONIn.getJSONArray(i1).size()];
      for (int i2 = 0; i2 < JSONIn.getJSONArray(i1).size(); i2++) {
        out2[i2] = JSONIn.getJSONArray(i1).getInt(i2);
      } 
      out[i1] = out2;
    }
    return out;
  }
  public PVector ucopy (PVector IN) {
    return (new PVector (IN.x, IN.y));
  }
  public int[] ucopy (int[] IN) {
    int[] rez = new int[IN.length];
    for (int i = 0; i < IN.length; i++) {
      rez[i] = IN[i];
    }
    return rez;
  }
  public int[][] ucopy (int[][] IN) {
    int[][] rez = new int[IN.length][0];
    for (int i = 0; i < IN.length; i++) {
      rez[i] = ucopy(IN[i]);
    }
    return rez;
  }
  public String[][] ucopy (String[][] IN) {
    String[][] rez = new String[IN.length][0];
    for (int i = 0; i < IN.length; i++) {
      rez[i] = ucopy(IN[i]);
    }
    return rez;
  }
  public String[] ucopy (String[] IN) {
    String[] rez = new String[IN.length];
    for (int i = 0; i < IN.length; i++) {
      rez[i] = IN[i];
    }
    return rez;
  }
  public JSONObject uloadJSONObject (String path) {
    String[] strings = loadStrings(path);
    String joined = "";
    for (int x = 0; x<strings.length; x++) {
      joined = joined+strings[x];
    }
    return JSONObject.parse(joined);
  }
  public void usaveJSONObject (JSONObject tosave, String path) {
    String[] strout = new String[1];
    strout[0] = tosave.toString();
    saveStrings(path, strout);
  } 
  public JSONArray uloadJSONArray (String path) {

    String[] strings = loadStrings(path);
    String joined = "";
    for (int x = 0; x<strings.length; x++) {
      joined = joined+strings[x];
    }
    return JSONArray.parse(joined);
  }
  public void usaveJSONArray (JSONArray tosave, String path) {
    String[] strout = new String[1];
    strout[0] = tosave.toString();
    saveStrings(path, strout);
  } 
  public String uselectInput (String title, String callback) {
    return "";
  }
  public String uselectOutput (String title, String callback) {
    return"";
  }
  public boolean distChk(PVector p1, PVector p2, float comp) {
    if (U.distSq(p1, p2) < comp*comp) return true;
    return false;
  }
  //if dist between 1234 is less than 5 then true else false
  public boolean distChk(float p1x, float p1y, float p2x, float p2y, float comp) {
    if ((p1x-p2x)*(p1x-p2x)+(p1y-p2y)*(p1y-p2y) < comp*comp) return true;
    return false;
  }
  public float distSq (PVector p1, PVector p2) {
    return (p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y) ;
  } 
  public float distSq (float p1x, float p1y, float p2x, float p2y) {
    return (p1x-p2x)*(p1x-p2x)+(p1y-p2y)*(p1y-p2y) ;
  }

  public float distSq (float p1x, float p1y, float p1z, float p2x, float p2y, float p2z) {
    return (p1x-p2x)*(p1x-p2x)+(p1y-p2y)*(p1y-p2y)+(p1z-p2z)*(p1z-p2z) ;
  }
  public boolean isOn (float x, float y, float sx, float sy, float ex, float ey) {
    return (x > sx & y > sy & x < ex & y < ey);
  }
}
public JSONArray loadJSONArray(String path) {
  return U.uloadJSONArray(path);
}
public JSONObject loadJSONObject(String path) {
  return U.uloadJSONObject(path);
}
public JSONArray parseJSONArray(String s) {
  return JSONArray.parse(s);
}
public JSONObject parseJSONObject(String s) {
  return JSONObject.parse(s);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "P5Parser" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
